# Tighten — Installation

## Project-level (recommended)

Copy the `tighten/` directory into your Antigravity skills folder:

```bash
cp -r tighten/ .antigravity/skills/tighten
```

The agent will auto-detect it for any prompt that matches the skill
description (tighten, refine, minimize, clean up, order, etc).

## Global (all projects)

```bash
cp -r tighten/ ~/.gemini/skills/tighten
```

## Usage

**Single file:**
```
tighten corekit/lib/vertex-text.mjs
```

**Directory sweep:**
```
tighten corekit/lib/
```

**Audit only (no changes):**
```
tighten review corekit/lib/firestore.mjs
```

**Resume after approval:**
The agent processes one file at a time and waits for your OK before
proceeding. Say "next", "approve", or "looks good" to continue.
Say "skip" to move to the next file without applying changes.
Say "stop tighten" to exit.

## What it does

Three passes per file, applied as a single rewrite:

1. **Minimize** — dead code, redundant logic, stdlib replacements.
   Architecture-safe: never touches error handling, security patterns,
   shared module boundaries, or canon-mandated structures.

2. **Comment** — enforces the project's canon comment strategy: file headers
   with path/purpose/provenance/consumers, JSDoc on exports, inline "why"
   comments, canon references where non-obvious.

3. **Order** — reorders declarations to follow execution flow (callee-before-
   caller). Reading top-to-bottom follows the code's logic path. Import
   grouping: builtins → corekit/lib → local.

## Compatible agents

Any SKILL.md-compatible environment: Google Antigravity, Antigravity CLI,
Claude Code, Cursor, Windsurf, Codex.

For Claude Code: copy to `.claude/skills/tighten/`.
For Cursor: adapt the SKILL.md content into `.cursor/rules/tighten.mdc`.
